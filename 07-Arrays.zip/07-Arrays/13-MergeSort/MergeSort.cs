﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class MergeSort
{
     static void Main()
    {
      //Write a program that sorts an array of integers using the merge sort algorithm (find it in Wikipedia).
  
    
    }
}

